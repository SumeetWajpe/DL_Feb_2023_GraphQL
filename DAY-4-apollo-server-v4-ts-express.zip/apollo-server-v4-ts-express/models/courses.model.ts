import mongoose, { Schema } from "mongoose";

const CoursesSchema = new Schema({
  id: String,
  title: String,
  price: Number,
  rating: Number,
  likes: Number,
  imageUrl: String,
  trainerId: String,
});
export let Course = mongoose.model("courses", CoursesSchema);
