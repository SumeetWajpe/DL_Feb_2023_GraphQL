import express from "express";
import { ApolloServer } from "@apollo/server";
import { expressMiddleware } from "@apollo/server/express4";
import cors from "cors";
import pkg from "body-parser";
const { json } = pkg;
import { typeDefs } from "../schema/typeDefs.js";
import { resolvers } from "../schema/resolvers.js";

const app = express();
const port = 3000;

const server = new ApolloServer({ typeDefs, resolvers });
await server.start();
app.use(
  "/graphql",
  cors<cors.CorsRequest>(),
  json(),
  expressMiddleware(server),
);

app.listen(port, () => {
  console.log(`Example app listening on port ${port}`);
});

app.listen(4000, () => {
  console.log("Apollo Server running at http://localhost:4000/graphql");
});
