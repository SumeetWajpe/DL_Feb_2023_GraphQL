import { coursesList } from "../models/courses.model.js";
import { trainersList } from "../models/trainers.model.js";

export const resolvers = {
  Query: {
    trainers: () => trainersList,
    trainer: (_, args) => trainersList.find(trainer => trainer.id == args.id),
    courses: () => coursesList,
    course: (_, args) => coursesList.find(course => course.id == args.id),
  },
  Course: {
    trainer: parent =>
      trainersList.find(trainer => trainer.id == parent.trainerId),
  },
};
