export let trainersList = [
  {
    id: 1,
    name: "John Carter",
    isMCT: true,
    followers: 100,
    avatarUrl: "https://avatars.githubusercontent.com/u/1?v=4",
  },
  {
    id: 2,
    name: "John Mojombo",
    isMCT: true,
    followers: 700,
    avatarUrl: "https://avatars.githubusercontent.com/u/2?v=4",
  },
  {
    id: 3,
    name: "Allen Defunkt",
    isMCT: true,
    followers: 400,
    avatarUrl: "avatars.githubusercontent.com/u/3?v=4",
  },
];

