import { ApolloServer } from "@apollo/server";
import { startStandaloneServer } from "@apollo/server/standalone";
import { typeDefs } from "../schema/typeDefs.js";
import { resolvers } from "../schema/resolvers.js";

const server = new ApolloServer({ typeDefs, resolvers });
// 1. Create an express app
//2. installs ApolloServer as an middleware
//3. prepares app to handle incoming request
const { url } = await startStandaloneServer(server, { listen: { port: 4000 } });
console.log(`Apollo Server running @ ${url} !`);
