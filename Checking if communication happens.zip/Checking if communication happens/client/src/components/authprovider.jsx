import React, { createContext, ReactNode, useContext, useState } from "react";
import { CurrentUser } from "../../models/currentuser.model";

const AuthContext = createContext();

const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(new CurrentUser());
  const login = (user) => {
    setUser(user);
  };
  const logout = () => {
    setUser({
      name: "",
      email:"",
      password: "",
      isLoggedIn: false,
    });
  };
  return (
    <AuthContext.Provider value={{ user, login, logout }}>
      {children}
    </AuthContext.Provider>
  );
};

// Custom Hook - Definition
export const useAuth = () => {
  return useContext(AuthContext);
};

export default AuthProvider;
