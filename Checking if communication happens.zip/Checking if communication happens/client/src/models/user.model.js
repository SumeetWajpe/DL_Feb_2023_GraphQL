export class CurrentUser {
  name = "";
  email = "";
  password = "";
  isLoggedIn = false;
}
