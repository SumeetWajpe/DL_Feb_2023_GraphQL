import logo from "./logo.svg";
import "./App.css";
import ListOfCourses from "./components/listofcourse.component";

function App() {
  return (
    <div >
     
      <div>
        <ListOfCourses />
      </div>
    </div>
  );
}

export default App;
