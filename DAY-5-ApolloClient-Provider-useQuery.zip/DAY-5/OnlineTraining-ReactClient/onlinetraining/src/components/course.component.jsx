export function Course(props) {
  let ratings = [];
  for (let i = 0; i < props.coursedetails.rating; i++) {
    ratings.push(
      <i
        className="fa-sharp fa-solid fa-star"
        style={{ color: "orange" }}
        key={i}
      ></i>,
    );
  }
  return (
    <div className="col-md-3 ">
      <div className="card" style={{ width: "18rem" }}>
        <img
          src={props.coursedetails.imageUrl}
          className="card-img-top"
          alt={props.coursedetails.title}
          height="150px"
        />
        <div className="card-body rounded-0">
          <div className="d-flex justify-content-between">
            {" "}
            <h5 className="card-title p-0">{props.coursedetails.title}</h5>
            <p className="card-text">{ratings}</p>
          </div>
          <p className="card-text">₹.{props.coursedetails.price}</p>
          <button className="btn btn-primary">
            {props.coursedetails.likes}
            <i className="fa-regular fa-thumbs-up"></i>
          </button>{" "}
          <button className="btn btn-danger">
            <i className="fa-solid fa-trash"></i>
          </button>
          <p className="card-text"></p>
        </div>
      </div>
    </div>
  );
}
