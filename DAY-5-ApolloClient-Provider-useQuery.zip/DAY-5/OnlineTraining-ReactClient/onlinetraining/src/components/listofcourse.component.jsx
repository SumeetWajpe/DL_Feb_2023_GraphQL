import { useQuery } from "@apollo/client";
import React, { useEffect, useState } from "react";
import { GET_ALL_COURSES } from "../graphql/querries";
import { Course } from "./course.component";

export default function ListOfCourses() {
  const { error, loading, data } = useQuery(GET_ALL_COURSES);
  const [courses, setCourses] = useState([]);

  useEffect(() => {
    if (!loading) {
      setCourses(data.courses);
    }
  }, [data]);

  return (
    <div>
      <header>
        <h2>List Of Courses</h2>
      </header>

      <div className="row g-2">
        {courses.map(course => (
          <Course coursedetails={course} key={course.id} />
        ))}
      </div>
    </div>
  );
}
