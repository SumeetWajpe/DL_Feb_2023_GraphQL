import express from "express";
import { ApolloServer } from "@apollo/server";
import { expressMiddleware } from "@apollo/server/express4";
import cors from "cors";
import pkg from "body-parser";
const { json } = pkg;
import { typeDefs } from "../schema/typeDefs.js";
import { resolvers } from "../schema/resolvers.js";
import mongoose from "mongoose";

const app = express();

mongoose.connect("mongodb://localhost:27017/onlinetrainingdb");

mongoose.connection.once("open", () => {
  console.log("Connected to onlinetraining DB !");
});

const server = new ApolloServer({ typeDefs, resolvers });
await server.start();
app.use(
  "/graphql",
  cors<cors.CorsRequest>(), // CROSS ORIGIN RESOURCE SHARING (Header)
  json(),
  expressMiddleware(server),
);

app.listen(4000, () => {
  console.log("Apollo Server running at http://localhost:4000/graphql");
});
