import mongoose, { Schema } from "mongoose";

const TrainerSchema = new Schema({
  id: String,
  name: String,
  isMCT: Boolean,
  followers: Number,
  avatarUrl: String,
});
export let Trainer = mongoose.model("trainers", TrainerSchema);
