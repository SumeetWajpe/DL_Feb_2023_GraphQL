import { Course } from "../models/courses.model.js";
import { Trainer } from "../models/trainers.model.js";

export const resolvers = {
  Query: {
    trainers: async () => await Trainer.find({}), // select * from
    trainer: async (_, args) => await Trainer.findOne({ id: +args.id }),
    courses: async () => await Course.find({}),
    course: async (_, args) => await Course.findOne({ id: args.id }),
  },

  Mutation: {
    createTrainer: async (_, { id, name, isMCT, followers, avatarUrl }) => {
      // insert new Trainer in DB
      let newTrainer = new Trainer({ id, name, isMCT, followers, avatarUrl });
      await newTrainer.save();
      return newTrainer;
    },
    deleteCourse: async (_, { id }) => {
      await Course.deleteOne({ id });
      return id;
    },
  },

  Course: {
    trainer: async parent => await Trainer.findOne({ id: parent.trainerId }),
  },
};
