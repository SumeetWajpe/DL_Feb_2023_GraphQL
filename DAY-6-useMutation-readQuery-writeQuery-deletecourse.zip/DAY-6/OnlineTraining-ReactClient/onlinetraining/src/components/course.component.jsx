import { useMutation } from "@apollo/client";
import { Link } from "react-router-dom";
import { DELETE_A_COURSE } from "../graphql/mutations";
import { GET_ALL_COURSES } from "../graphql/querries";

export function Course(props) {
  const [deleteCourse, { error, loading, data }] = useMutation(
    DELETE_A_COURSE,
    {
      variables: { deleteCourseId: props.coursedetails.id },
      //refetchQueries: [{ query: GET_ALL_COURSES }], // it refetched data from server
      update(cache, { deleteOpdata }) {
        // readQuery -reads from the cache
        const { courses } = cache.readQuery({ query: GET_ALL_COURSES });

        cache.writeQuery({
          query: GET_ALL_COURSES,
          data: {
            courses: courses.filter(c => c.id !== props.coursedetails.id),
          },
        });
      },
    },
  );

  let ratings = [];
  for (let i = 0; i < props.coursedetails.rating; i++) {
    ratings.push(
      <i
        className="fa-sharp fa-solid fa-star"
        style={{ color: "orange" }}
        key={i}
      ></i>,
    );
  }
  return (
    <div className="col-md-3 ">
      <div className="card" style={{ width: "18rem" }}>
        <img
          src={props.coursedetails.imageUrl}
          className="card-img-top"
          alt={props.coursedetails.title}
          height="150px"
        />
        <div className="card-body rounded-0">
          <div className="d-flex justify-content-between">
            {" "}
            <h5 className="card-title p-0">
              <Link to={`/coursedetails/${props.coursedetails.id}`}>
                {props.coursedetails.title}
              </Link>
            </h5>
            <p className="card-text">{ratings}</p>
          </div>
          <p className="card-text">₹.{props.coursedetails.price}</p>
          <button className="btn btn-primary">
            {props.coursedetails.likes}
            <i className="fa-regular fa-thumbs-up"></i>
          </button>{" "}
          <button className="btn btn-danger" onClick={() => deleteCourse()}>
            <i className="fa-solid fa-trash"></i>
          </button>
          <p className="card-text"></p>
        </div>
      </div>
    </div>
  );
}
