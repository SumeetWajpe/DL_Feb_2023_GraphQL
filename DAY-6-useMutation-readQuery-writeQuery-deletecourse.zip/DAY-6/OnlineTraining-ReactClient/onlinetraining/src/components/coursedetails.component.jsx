import { useQuery } from "@apollo/client";
import React, { useState, useEffect } from "react";
import { useParams } from "react-router-dom";
import { client } from "../index";
import { GET_ALL_COURSES, GET_COURSE_BY_ID } from "../graphql/querries";

export default function CourseDetails() {
  const [theCourse, setCourse] = useState({});
  const { id } = useParams();

  useEffect(() => {
    // fetch the data from cache
    const { courses } = client.readQuery({
      query: GET_ALL_COURSES,// Only querries executed earlier can be a part of readQuery
    });

    let currentCourse = courses.find(c => c.id == id);
    setCourse(currentCourse);
  });

  let ratings = [];
  for (let i = 0; i < theCourse?.rating; i++) {
    ratings.push(
      <i
        className="fa-sharp fa-solid fa-star"
        style={{ color: "orange" }}
        key={i}
      ></i>,
    );
  }
  return (
    <div>
      <h2>Course Details </h2>

      <h3>{theCourse?.title}</h3>

      <div className="row">
        <div className="col-md-8">
          <img
            src={theCourse?.imageUrl}
            className="card-img-top"
            alt={theCourse?.title}
            width="100%"
            height="100%"
          />
        </div>
        <div className="col-md-4">
          <p className="card-text">{ratings}</p>
          <p className="card-text">₹.{theCourse?.price}</p>
          <button className="btn btn-primary">
            {theCourse?.likes}
            <i className="fa-regular fa-thumbs-up"></i>
          </button>{" "}
          <button className="btn btn-danger">
            <i className="fa-solid fa-trash"></i>
          </button>
          <p className="card-text">{theCourse?.trainer?.name}</p>
        </div>
      </div>
    </div>
  );
}

// This is fetching from server (using useQuery hook)

// import { useQuery } from "@apollo/client";
// import React, { useState, useEffect } from "react";
// import { useParams } from "react-router-dom";
// import { GET_COURSE_BY_ID } from "../graphql/querries";

// export default function CourseDetails() {
//   const [theCourse, setCourse] = useState({});
//   const { id } = useParams();

//   let { error, loading, data } = useQuery(GET_COURSE_BY_ID, {
//     variables: { courseId: id },
//   });
//   useEffect(() => {
//     if (!loading) {
//       setCourse(data.course);
//     }
//   }, [data]);

//   let ratings = [];
//   for (let i = 0; i < theCourse?.rating; i++) {
//     ratings.push(
//       <i
//         className="fa-sharp fa-solid fa-star"
//         style={{ color: "orange" }}
//         key={i}
//       ></i>,
//     );
//   }
//   return (
//     <div>
//       <h2>Course Details </h2>

//       <h3>{theCourse?.title}</h3>

//       <div className="row">
//         <div className="col-md-8">
//           <img
//             src={theCourse?.imageUrl}
//             className="card-img-top"
//             alt={theCourse?.title}
//             width="100%"
//             height="100%"
//           />
//         </div>
//         <div className="col-md-4">
//           <p className="card-text">{ratings}</p>
//           <p className="card-text">₹.{theCourse?.price}</p>
//           <button className="btn btn-primary">
//             {theCourse?.likes}
//             <i className="fa-regular fa-thumbs-up"></i>
//           </button>{" "}
//           <button className="btn btn-danger">
//             <i className="fa-solid fa-trash"></i>
//           </button>
//           <p className="card-text">{theCourse?.trainer?.name}</p>
//         </div>
//       </div>
//     </div>
//   );
// }
