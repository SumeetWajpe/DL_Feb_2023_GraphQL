import { gql } from "@apollo/client";

export const GET_ALL_COURSES = gql`
  query GetAllCourses {
    courses {
      id
      title
      price
      likes
      rating
      imageUrl
      trainer {
        name
      }
    }
  }
`;
// Use fragments as bet practise

export const GET_COURSE_BY_ID = gql`
  query GetCourseById($courseId: ID!) {
    course(id: $courseId) {
      id
      title
      price
      likes
      rating
      imageUrl
      trainer {
        name
      }
    }
  }
`;
