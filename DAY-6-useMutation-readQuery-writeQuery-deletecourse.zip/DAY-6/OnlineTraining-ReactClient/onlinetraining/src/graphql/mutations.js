import { gql } from "@apollo/client";

export const DELETE_A_COURSE = gql`
  mutation DeleteACourseMutation($deleteCourseId: ID!) {
    deleteCourse(id: $deleteCourseId)
  }
`;
