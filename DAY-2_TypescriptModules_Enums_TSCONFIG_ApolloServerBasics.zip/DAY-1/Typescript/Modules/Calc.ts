import { Add as addition } from "./Math";

console.log(`The addition is : ${addition(20, 30)}`);
