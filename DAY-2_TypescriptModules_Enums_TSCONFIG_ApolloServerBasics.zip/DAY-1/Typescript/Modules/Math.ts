// named export
export function Add(x: number, y: number): number {
  return x + y;
}

export default function Product(x: number, y: number): number {
  return x * y;
}

export function Divide(x, y) {
  return x / y;
}
