// let str = "Hello Typescript !"; // Type inferencing !
// //str = 100;
// var x: number; // Type annotation
// x = 100;

// var y; // bad practise
// y = 100;
// y = {};
// y = [10, 20, 30];
// y = "Anything !";

// console.log(typeof str);
// console.log(typeof y);

// Scoping (JS) - Global / Local (Function)

// ES6 - Block Scoping

if (true) {
  let x = 100;
  // later 100 lines of code
  //   let x = 200; // Error
}

// console.log(x); // Error !
let x = 10;

const PI = 3.14; // Block Scoping

// Functions
function Add(x: number, y: number): number | string {
  if (x <= 0) {
    return "x cannot be less than zero !";
  }
  return x + y;
}

// let result: number | string = Add(20, 30);
// console.log(result);

// Parameters
// 1. Optional

// function PrintBook(author?: string, title?: string, noOfPages?: number) {
//   console.log(author, title, noOfPages);
// }

// PrintBook();
// PrintBook("Dr. APJ Abdul Kalam", "Wings Of Fire", 200);

// 2. Default Parameters

function PrintBook(
  author: string = "Unknown",
  title: string = "Unknown",
  noOfPages: number = 0,
) {
  console.log(author, title, noOfPages);
}

// PrintBook();
// PrintBook("Dr. APJ Abdul Kalam", "Wings Of Fire", 200);
// PrintBook(undefined, "Dummy", 200);

// 3. Rest Parameters
// function PrintBook(author: string, ...titles: string[]) {
//   console.log(author, titles);
// }

// PrintBook("Dr. APJ Abdul Kalam", "India 2020", "Wings Of Fire");
// PrintBook("Sachin Tendulkar", "Playing It My Way");

// Arrow Functions
// var Square = function (x: number): number {
//   return x * x;
// };

// OR
// var Square = (x: number): number => {
//   return x * x;
// };

// OR

// var Square = (x: number): number => x * x;
// console.log("The square is " + Square(10));

// let cars: string[] = ["BMW", "AUDI", "MERC"];
// // cars.forEach(function (car) {
// //   console.log(car);
// // });

// cars.forEach((car: string) => console.log(car));

// function Emp() {
//   this.salary = 200000;
//   setTimeout(() => console.log(this.salary), 2000);
// }

// var e = new Emp(); // Constructor

// Destructuring - Read out values from an Array / Object
// 1. With Arrays

// let cars: string[] = ["BMW", "AUDI", "MERC"];
// let firstCar, secondCar;
// firstCar = cars[0];
// secondCar = cars[1];
// OR
// let [firstCar, , , secondCar = "Dummy"] = ["BMW", "AUDI", "MERC"];
// console.log(firstCar, secondCar);

// With Objects
// let player = {
//   fname: "Roger",
//   lname: "Federer",
//   country: "Switzerland",
//   sport: "Tennis",
// };
// let fname, lname;
// fname = player.fname;
// lname = player.lname;
// OR
// let { lname, fname, ...restProps } = player;
// console.log(fname, lname, restProps);

// function PrintPlayer({ fname, country }) {
//   //   console.log("The player " + fname + " represents " + country);
//   console.log(`The player ${fname} represents ${country}`);
// }

// PrintPlayer(player);
// console.log(player);

// let multiLineStr: string = `First Line
//     Second Line
// Last Line !`;
// console.log(multiLineStr);

// Enhanced Object Literal Syntax

// let fname: string = "Sachin";
// let sport: string = "Cricket";
// let player = { fname: fname, sport: sport };
// OR
// let player = { fname, sport };

// Spread Operator
// With Arrays

// let cars: string[] = ["BMW", "AUDI", "MERC"];
// OR
let cars: Array<string> = new Array<string>("BMW", "AUDI", "MERC");
let moreCars: string[] = ["TATA", "MAHINDRA"];
let allCars: string[] = [...cars, ...moreCars];
cars[0] = "XYZ";
console.log(allCars);

// With Objects
let person = {
  fname: "Roger",
  lname: "Federer",
  country: "Switzerland",
};

let player = { ...person, sport: "Tennis", hasRetired: true, country: "Swiss" };
console.log(player);

// Interfaces
// interface ICompany {
//   name: string;
//   location?: string;
//   getDetails?: () => void;
// }
// interface iMNC extends ICompany {
//   isMNC: boolean;
// }

// type Company = {
//   name: string;
//   location: string;
// };
// let company: ICompany = { name: "Microsoft" };

// Classes
class Car {
  //   private id: number;
  name: string;
  speed: number;
  constructor(name: string = "BMW", speed: number = 200) {
    this.name = name;
    this.speed = speed;
  }
  printDetails() {
    console.log("Details here");
  }

  accelerate(): string {
    return `The car ${this.name} is running at ${this.speed} kmph !`;
  }
}

let carObj: Car = new Car();
console.log(carObj.accelerate());

class JamesBondCar extends Car {
  hasNitroPower: boolean;
  constructor(name: string, speed: number, hasNitroPower: boolean) {
    super(name, speed);
    this.hasNitroPower = hasNitroPower;
  }
  accelerate(): string {
    return super.accelerate() + " Can usenitro power ? " + this.hasNitroPower;
  }
}

let jbc: JamesBondCar = new JamesBondCar("Aston Martin", 300, true);
console.log(jbc.accelerate());
jbc.printDetails();

// interface ICompany {
//   name: string;
//   location?: string;
//   getDetails?: () => void;
// }
// interface iMNC {
//   isMNC: boolean;
// }

// class Enterprise implements ICompany, iMNC {
//   name: string;
//   location?: string;
//   isMNC: boolean;

//   getDetails() {
//     console.log("Get details of company !");
//   }
// }
// Enhanced Class Syntax

class EnhancedCar {
  constructor(public name: string = "BMW", public speed: number = 100) {}
}

let enhancedObj: EnhancedCar = new EnhancedCar();
console.log(enhancedObj.name);

// Generics

function Swap<T>(x: T, y: T) {
  let temp: T;
  temp = x;
  x = y;
  y = temp;
}

Swap<number>(20, 30);
Swap<string>("Hello", "World !");

class Point<T> {
  x: T;
  y: T;

  print(): T {
    return x as T;
  }
}

let pointwithNumbers = new Point<number>();

// Function Overloading
// function PrintCompany();
// function PrintCompany(name: string);
// function PrintCompany(name?: string, location?: string) {}

// PrintCompany();

// Enums
enum Designation {
  Trainer = 100,
  Developer,
  Architect,
  Tester,
}

let myDesignation: Designation;
myDesignation = Designation.Architect;
// console.log(myDesignation);
console.log(Designation[myDesignation]);

class Emp {
  name: string;
  designation: Designation;
}

// Decorator - emits out metadata

// Usage - @Decorator - Classes , methods, Member Variables

function Square(x: number) {
  return x * x;
}
