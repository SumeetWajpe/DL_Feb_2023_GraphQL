// let str = "Hello Typescript !"; // Type inferencing !
// //str = 100;
// var x: number; // Type annotation
// x = 100;
// var y; // bad practise
// y = 100;
// y = {};
// y = [10, 20, 30];
// y = "Anything !";
// console.log(typeof str);
// console.log(typeof y);
// Scoping (JS) - Global / Local (Function)
// ES6 - Block Scoping
if (true) {
    let x = 100;
    // later 100 lines of code
    //   let x = 200; // Error
}
// console.log(x); // Error !
let x = 10;
const PI = 3.14; // Block Scoping
// Functions
function Add(x, y) {
    if (x <= 0) {
        return "x cannot be less than zero !";
    }
    return x + y;
}
// let result: number | string = Add(20, 30);
// console.log(result);
// Parameters
// 1. Optional
// function PrintBook(author?: string, title?: string, noOfPages?: number) {
//   console.log(author, title, noOfPages);
// }
// PrintBook();
// PrintBook("Dr. APJ Abdul Kalam", "Wings Of Fire", 200);
// 2. Default Parameters
function PrintBook(author = "Unknown", title = "Unknown", noOfPages = 0) {
    console.log(author, title, noOfPages);
}
// PrintBook();
// PrintBook("Dr. APJ Abdul Kalam", "Wings Of Fire", 200);
// PrintBook(undefined, "Dummy", 200);
// 3. Rest Parameters
// function PrintBook(author: string, ...titles: string[]) {
//   console.log(author, titles);
// }
// PrintBook("Dr. APJ Abdul Kalam", "India 2020", "Wings Of Fire");
// PrintBook("Sachin Tendulkar", "Playing It My Way");
// Arrow Functions
// var Square = function (x: number): number {
//   return x * x;
// };
// OR
// var Square = (x: number): number => {
//   return x * x;
// };
// OR
// var Square = (x: number): number => x * x;
// console.log("The square is " + Square(10));
// let cars: string[] = ["BMW", "AUDI", "MERC"];
// // cars.forEach(function (car) {
// //   console.log(car);
// // });
// cars.forEach((car: string) => console.log(car));
// function Emp() {
//   this.salary = 200000;
//   setTimeout(() => console.log(this.salary), 2000);
// }
// var e = new Emp(); // Constructor
// Destructuring - Read out values from an Array / Object
// 1. With Arrays
// let cars: string[] = ["BMW", "AUDI", "MERC"];
// let firstCar, secondCar;
// firstCar = cars[0];
// secondCar = cars[1];
// OR
// let [firstCar, , , secondCar = "Dummy"] = ["BMW", "AUDI", "MERC"];
// console.log(firstCar, secondCar);
// With Objects
// let player = {
//   fname: "Roger",
//   lname: "Federer",
//   country: "Switzerland",
//   sport: "Tennis",
// };
// let fname, lname;
// fname = player.fname;
// lname = player.lname;
// OR
// let { lname, fname, ...restProps } = player;
// console.log(fname, lname, restProps);
// function PrintPlayer({ fname, country }) {
//   //   console.log("The player " + fname + " represents " + country);
//   console.log(`The player ${fname} represents ${country}`);
// }
// PrintPlayer(player);
// console.log(player);
// let multiLineStr: string = `First Line
//     Second Line
// Last Line !`;
// console.log(multiLineStr);
// Enhanced Object Literal Syntax
// let fname: string = "Sachin";
// let sport: string = "Cricket";
// let player = { fname: fname, sport: sport };
// OR
// let player = { fname, sport };
// Spread Operator
// With Arrays
// let cars: string[] = ["BMW", "AUDI", "MERC"];
// OR
let cars = new Array("BMW", "AUDI", "MERC");
let moreCars = ["TATA", "MAHINDRA"];
let allCars = [...cars, ...moreCars];
cars[0] = "XYZ";
console.log(allCars);
// With Objects
let person = {
    fname: "Roger",
    lname: "Federer",
    country: "Switzerland",
};
let player = Object.assign(Object.assign({}, person), { sport: "Tennis", hasRetired: true, country: "Swiss" });
console.log(player);
// Interfaces
// interface ICompany {
//   name: string;
//   location?: string;
//   getDetails?: () => void;
// }
// interface iMNC extends ICompany {
//   isMNC: boolean;
// }
// type Company = {
//   name: string;
//   location: string;
// };
// let company: ICompany = { name: "Microsoft" };
// Classes
class Car {
    constructor(name = "BMW", speed = 200) {
        this.name = name;
        this.speed = speed;
    }
    printDetails() {
        console.log("Details here");
    }
    accelerate() {
        return `The car ${this.name} is running at ${this.speed} kmph !`;
    }
}
let carObj = new Car();
console.log(carObj.accelerate());
class JamesBondCar extends Car {
    constructor(name, speed, hasNitroPower) {
        super(name, speed);
        this.hasNitroPower = hasNitroPower;
    }
    accelerate() {
        return super.accelerate() + " Can usenitro power ? " + this.hasNitroPower;
    }
}
let jbc = new JamesBondCar("Aston Martin", 300, true);
console.log(jbc.accelerate());
jbc.printDetails();
// interface ICompany {
//   name: string;
//   location?: string;
//   getDetails?: () => void;
// }
// interface iMNC {
//   isMNC: boolean;
// }
// class Enterprise implements ICompany, iMNC {
//   name: string;
//   location?: string;
//   isMNC: boolean;
//   getDetails() {
//     console.log("Get details of company !");
//   }
// }
// Enhanced Class Syntax
class EnhancedCar {
    constructor(name = "BMW", speed = 100) {
        this.name = name;
        this.speed = speed;
    }
}
let enhancedObj = new EnhancedCar();
console.log(enhancedObj.name);
// Generics
function Swap(x, y) {
    let temp;
    temp = x;
    x = y;
    y = temp;
}
Swap(20, 30);
Swap("Hello", "World !");
class Point {
    print() {
        return x;
    }
}
let pointwithNumbers = new Point();
// Function Overloading
// function PrintCompany();
// function PrintCompany(name: string);
// function PrintCompany(name?: string, location?: string) {}
// PrintCompany();
// Enums
var Designation;
(function (Designation) {
    Designation[Designation["Trainer"] = 100] = "Trainer";
    Designation[Designation["Developer"] = 101] = "Developer";
    Designation[Designation["Architect"] = 102] = "Architect";
    Designation[Designation["Tester"] = 103] = "Tester";
})(Designation || (Designation = {}));
let myDesignation;
myDesignation = Designation.Architect;
// console.log(myDesignation);
console.log(Designation[myDesignation]);
class Emp {
}
// Decorator - emits out metadata
// Usage - @Decorator - Classes , methods, Member Variables
function Square(x) {
    return x * x;
}
