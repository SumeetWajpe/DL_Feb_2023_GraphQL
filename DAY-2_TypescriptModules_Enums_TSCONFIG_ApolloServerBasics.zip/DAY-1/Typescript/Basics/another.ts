function Addition(x: number, y: number) {
  return x + y;
}
