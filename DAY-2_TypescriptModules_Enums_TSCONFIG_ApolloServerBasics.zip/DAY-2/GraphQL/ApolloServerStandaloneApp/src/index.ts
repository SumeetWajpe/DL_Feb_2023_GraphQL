import { ApolloServer } from "@apollo/server";
import { startStandaloneServer } from "@apollo/server/standalone";
const typeDefs = `#graphql
    type Query{
        hello:String
    }
`;

const resolvers = {
  Query: {
    hello: () => "Hello GraphQL !",
  },
};

const server = new ApolloServer({ typeDefs, resolvers });
// 1. Create an express app
//2. installs ApolloServer as an middleware
//3. prepares app to handle incoming request
await startStandaloneServer(server, { listen: { port: 4000 } });
console.log(`Apollo Server running @ 4000 !`);
