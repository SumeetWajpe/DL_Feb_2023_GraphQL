import React, { ReactNode } from "react";
import { Navigate, useLocation } from "react-router-dom";
import { useAuth } from "./authprovider";

function RequireAuth({ children }) {
  const authCtx = useAuth();
  const location = useLocation();
  console.log("Req Auth", authCtx.user);
  if (!authCtx?.user.isLoggedIn) {
    // return <Navigate to="/" state={{ path: location.pathname }} />;
    return <Navigate to="/" />;
  }
  return children;
}

export default RequireAuth;
